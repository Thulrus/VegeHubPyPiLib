"""Package for VegeHub communication."""

from vegehub.vegehub import VegeHub
